#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import  media
import fresh_tomatoes

movie1 = media.Movie('烽火芳菲','两获金棕榈、手捧奥斯卡最佳外语片奖杯的国际电影大师比利·奥古斯特最新执导的二战巨制《烽火芳菲》将于11月10日全国公映，该片由刘亦菲、埃米尔·赫斯基、严屹宽、余少群等实力演员联袂出演。今日片方发布了一支剧情版预告，预告中炮火连天的战斗场面惊心动魄，伴随着紧张的节奏，演员细腻的表演，将观众带入军民同心营救美国飞行员的紧张气氛中。','https://gss3.bdstatic.com/-Po3dSag_xI4khGkpoWK1HF6hhy/baike/c0%3Dbaike92%2C5%2C5%2C92%2C30/sign=5f2c4f53c1ef7609280691cd4fb4c8a9/50da81cb39dbb6fd01beaee80324ab18962b3712.jpg','https://www.youtube.com/embed/rB90ja-o-sI')
movie2 = media.Movie('烽火芳菲','两获金棕榈、手捧奥斯卡最佳外语片奖杯的国际电影大师比利·奥古斯特最新执导的二战巨制《烽火芳菲》将于11月10日全国公映，该片由刘亦菲、埃米尔·赫斯基、严屹宽、余少群等实力演员联袂出演。今日片方发布了一支剧情版预告，预告中炮火连天的战斗场面惊心动魄，伴随着紧张的节奏，演员细腻的表演，将观众带入军民同心营救美国飞行员的紧张气氛中。','https://gss3.bdstatic.com/-Po3dSag_xI4khGkpoWK1HF6hhy/baike/c0%3Dbaike92%2C5%2C5%2C92%2C30/sign=5f2c4f53c1ef7609280691cd4fb4c8a9/50da81cb39dbb6fd01beaee80324ab18962b3712.jpg','https://www.youtube.com/embed/rB90ja-o-sI')
movie3 = media.Movie('烽火芳菲','两获金棕榈、手捧奥斯卡最佳外语片奖杯的国际电影大师比利·奥古斯特最新执导的二战巨制《烽火芳菲》将于11月10日全国公映，该片由刘亦菲、埃米尔·赫斯基、严屹宽、余少群等实力演员联袂出演。今日片方发布了一支剧情版预告，预告中炮火连天的战斗场面惊心动魄，伴随着紧张的节奏，演员细腻的表演，将观众带入军民同心营救美国飞行员的紧张气氛中。','https://gss3.bdstatic.com/-Po3dSag_xI4khGkpoWK1HF6hhy/baike/c0%3Dbaike92%2C5%2C5%2C92%2C30/sign=5f2c4f53c1ef7609280691cd4fb4c8a9/50da81cb39dbb6fd01beaee80324ab18962b3712.jpg','https://www.youtube.com/embed/rB90ja-o-sI')
movie4 = media.Movie('烽火芳菲','两获金棕榈、手捧奥斯卡最佳外语片奖杯的国际电影大师比利·奥古斯特最新执导的二战巨制《烽火芳菲》将于11月10日全国公映，该片由刘亦菲、埃米尔·赫斯基、严屹宽、余少群等实力演员联袂出演。今日片方发布了一支剧情版预告，预告中炮火连天的战斗场面惊心动魄，伴随着紧张的节奏，演员细腻的表演，将观众带入军民同心营救美国飞行员的紧张气氛中。','https://gss3.bdstatic.com/-Po3dSag_xI4khGkpoWK1HF6hhy/baike/c0%3Dbaike92%2C5%2C5%2C92%2C30/sign=5f2c4f53c1ef7609280691cd4fb4c8a9/50da81cb39dbb6fd01beaee80324ab18962b3712.jpg','https://www.youtube.com/embed/rB90ja-o-sI')
movie5 = media.Movie('烽火芳菲','两获金棕榈、手捧奥斯卡最佳外语片奖杯的国际电影大师比利·奥古斯特最新执导的二战巨制《烽火芳菲》将于11月10日全国公映，该片由刘亦菲、埃米尔·赫斯基、严屹宽、余少群等实力演员联袂出演。今日片方发布了一支剧情版预告，预告中炮火连天的战斗场面惊心动魄，伴随着紧张的节奏，演员细腻的表演，将观众带入军民同心营救美国飞行员的紧张气氛中。','https://gss3.bdstatic.com/-Po3dSag_xI4khGkpoWK1HF6hhy/baike/c0%3Dbaike92%2C5%2C5%2C92%2C30/sign=5f2c4f53c1ef7609280691cd4fb4c8a9/50da81cb39dbb6fd01beaee80324ab18962b3712.jpg','https://www.youtube.com/embed/rB90ja-o-sI')
movie6 = media.Movie('烽火芳菲','两获金棕榈、手捧奥斯卡最佳外语片奖杯的国际电影大师比利·奥古斯特最新执导的二战巨制《烽火芳菲》将于11月10日全国公映，该片由刘亦菲、埃米尔·赫斯基、严屹宽、余少群等实力演员联袂出演。今日片方发布了一支剧情版预告，预告中炮火连天的战斗场面惊心动魄，伴随着紧张的节奏，演员细腻的表演，将观众带入军民同心营救美国飞行员的紧张气氛中。','https://gss3.bdstatic.com/-Po3dSag_xI4khGkpoWK1HF6hhy/baike/c0%3Dbaike92%2C5%2C5%2C92%2C30/sign=5f2c4f53c1ef7609280691cd4fb4c8a9/50da81cb39dbb6fd01beaee80324ab18962b3712.jpg','https://www.youtube.com/embed/rB90ja-o-sI')

movies = [movie1,movie2,movie3,movie4,movie5,movie6]
fresh_tomatoes.open_movies_page(movies)
